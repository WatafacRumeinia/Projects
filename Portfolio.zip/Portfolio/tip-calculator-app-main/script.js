class Calculator{

}

const inp=document.querySelector('input');
const percent5=document.getElementById('5prc');
const percent10=document.getElementById('10prc');
const percent15=document.getElementById('15prc');
const percent25=document.getElementById('25prc');
const percent50=document.getElementById('50prc');
const nrPpl=document.getElementById('nrOfPeople').value;
let sum=document.getElementsByClassName('tip');

sum.innerText="300";
